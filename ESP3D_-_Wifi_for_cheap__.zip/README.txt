                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3275572
ESP3D - Wifi for cheap ! by dvilleneuve is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a little wifi module for 3Dprinter based on ESP3D ans ESP8266.
I've made the diagram for the Gen L, mks-based and creality 1.1.2/1.1.3 (Cr-10/ender 3).
If your board is different, just find the +5v, GND, RX (or RXD0) and TX (or TXD0)

What else do you need ?

- Arduino IDE :  https://www.arduino.cc/en/Main/Software
- Must add this card on card manager : http://arduino.esp8266.com/stable/package_esp8266com_index.json
- ESP3D : https://github.com/luc-github/ESP3D/releases/latest
- Espressif download tool (if needed, to wipe the ESP8266) : https://www.espressif.com/sites/default/files/tools/flash_download_tools_v3.6.5_0.zip


- ESP-12F (esp8622)  :https://www.ebay.ca/itm/ESP8266-ESP-12F-WIFI-Microcontroller-802-11N-Module-Arduino-NodeMCU-MicroPython/272408386985?hash=item3f6cce1da9:g:PQ8AAOSwGotbUVAF:rk:8:pf:0
- Tact Switch  : https://www.ebay.ca/itm/100Pcs-6x6x4-5mm-Panel-PCB-Momentary-Tactile-Tact-4Pin-Push-Button-Switch/332381096445?hash=item4d637509fd:g:eroAAOSwlRZZvIGQ:rk:3:pf:0
- AMS1117 3.3v : https://www.ebay.ca/itm/50PCS-NEW-AMS1117-3-3-AMS1117-LM1117-3-3V-1A-SOT-223-Voltage-Regulator-IC/283081121012?hash=item41e8f31cf4:g:vF0AAOSw5cNYR3JA:rk:4:pf:0
- FTDi232 : https://www.ebay.ca/itm/FT232RL-FTDI232-USB-to-TTL-Serial-Adapter-Module-Arduino-Mini-Port-3-3V-5-5V-XJ/352427562648?hash=item520e51d698:g:dp0AAOSwtPlbbUW7:rk:1:pf:0
- Dupont femal connector : https://www.ebay.ca/itm/200-2-54mm-Dupont-Jumper-Wire-Cable-Housing-Female-Pin-Connector-Terminal/181302852182?hash=item2a367dfa56:g:-mgAAOSwg3FUmOER:rk:1:pf:0
	OR : Both - support and connector  :https://www.ebay.ca/itm/Jumper-Connectors-Pins-1-2-4-to-40-way-2-54mm-3D-Printer-Female-Dupont-Plugs/200995197390?hash=item2ecc3f51ce:m:mEklAecfpHBHxebKnnVTpgQ:rk:1:pf:0
	OR : The cable already made: https://www.ebay.ca/itm/Dupont-Cable-Female-to-Female-Prototyping-Hook-up-Cable-20cm-long-UK-Seller/182482963583?hash=item2a7cd50c7f:m:mGqVKYcZq22pldEPWZ9ovUQ:rk:2:pf:0

Have fun !